---
name: xtwin-model-classification-baseline
description: Update, explain, or review the xtwin-builder model and device-classification baseline, including ordered model archives and Excel-to-JSON classification generation. Use for model package replacement, classification baseline refreshes, or release checks in xtwin-builder; do not use for unrelated model-service changes.
---

# xtwin-builder 模型分类基线更新

以仓库当前代码和发布约定为准，完成模型包替换、设备分类清单生成和发布前校验。若用户只要求说明或评审，只读检查并输出步骤，不修改仓库。

## 先区分四类文件

| 对象 | 常见位置/形式 | 更新规则 |
| --- | --- | --- |
| 基础模型包 | `etc/init/releases-<timestamp>.tar.gz`，通常不带 `-lphd` | 用新包替换旧包，不要保留多个过期基础包 |
| 分类扩展包 | `etc/init/releases-<timestamp>-lphd.tar.gz` | 默认保留；只有用户提供了新版扩展包时才替换 |
| 设备分类清单 | `tools/init/in/设备分类.xlsx` 和生成的 `builtin_groups.json` | 每次从本体管理平台导出最新 Excel 后重新生成 |
| 测点分类基线 | `etc/init/builtin_capability.xlsx` | 本流程不更新，不要误当成设备分类 |

视频中的示例名是 `releases-202606251127.tar.gz` 和 `releases-203001161127-lphd.tar.gz`。它们只用于识别命名模式，不是应硬编码的新文件名。

## 关键机制

- 启动链路是 `cmd/xtwin-builder/main.go` 的 `GlobalUnit`，随后进入 `cmd/xtwin-builder/init.go` 的 `CreateBuiltinModels`。
- `pkg/model/bootstrap.go` 会遍历模型源目录并导入其中所有 `.tar.gz` 文件。导入先后受文件路径的字典序影响，因此时间戳文件名也是依赖顺序的一部分。
- 基础模型必须先导入，依赖它的 `-lphd` 分类扩展包必须排在后面。视频中把扩展包时间戳放到 2030 年是为维持这一顺序，不代表该名称永久有效。
- 更新时比较所有归档名，确认新基础包仍排在扩展包之前。如果新包时间戳越过扩展包，先停下并说明顺序风险，不要自行改扩展包名称。

若这些路径或函数已变化，沿当前调用链确认真实行为，不要机械沿用旧路径。

## 更新流程

1. 确认输入和工作区
   - 找到 `xtwin-builder` 仓库根目录，检查工作区状态并保留用户已有改动。
   - 确认用户提供的新基础模型 `.tar.gz` 和最新 `设备分类.xlsx`。缺少哪一项就只完成可完成部分，并明确报告。
   - 列出 `etc/init/` 下全部 `.tar.gz`，区分基础包和 `-lphd` 扩展包。

2. 替换基础模型包
   - 删除或移走被替代的旧基础模型包，将新基础模型包放入 `etc/init/`。
   - 不要以“追加”方式留下多个旧基础包；导入逻辑会处理目录里的所有 `.tar.gz`。
   - 默认不改 `-lphd` 包。若用户明确提供新版扩展包，则同样执行一对一替换。
   - 校验归档可读取，并再次确认文件名字典序满足“基础模型在前、分类扩展在后”。

3. 更新设备分类源表
   - 设备分类以本体管理平台导出的最新 `设备分类.xlsx` 为准。
   - 用新文件替换 `tools/init/in/设备分类.xlsx`。
   - 不要顺带修改 `标准化模板.xlsx`、`设备属性.xlsx` 或 `etc/init/builtin_capability.xlsx`，除非用户另有明确要求。

4. 生成分类 JSON
   - 在 `tools/init/in/` 目录运行：

     ```powershell
     go test -v -run TestConvertExcelToJSON
     ```

   - 该测试应从 `设备分类.xlsx` 生成 `tools/init/in/builtin_groups.json`。
   - 将生成文件替换到 `etc/init/builtin_groups.json`。使用文件复制而不是手工拼接 JSON。

5. 校验结果
   - 用 JSON 解析器读取两个 `builtin_groups.json`，并确认源文件与 `etc/init/` 中的交付文件一致。
   - 检查根对象含 `catalogs`，分类项的 `name`、`parent`、`displayName.text`、`includes` 等结构没有异常缺失。
   - 对比新旧分类数量和差异摘要；若出现大幅删减、空分类或大量未知引用，先报告并停止发布。
   - 检查 `etc/init/` 不存在被遗留的旧基础包或意外重复包，且 `builtin_capability.xlsx` 未被改动。
   - 查看最终工作区差异。正常变化通常只包括旧/新模型归档、`tools/init/in/设备分类.xlsx`、两处 `builtin_groups.json`，以及用户明确要求更新的扩展包。

6. 构建与交付
   - 查看仓库当前的 `cmd/xtwin-builder/pub.bat`、CI 配置或发布说明，使用仓库已有的测试和打包入口，不猜测命令。
   - 先完成本地可逆的测试和打包校验，再汇报修改文件、模型导入顺序、分类差异和验证结果。
   - 提交、推送、创建 tag 或触发远端发布会改变外部状态；仅在用户明确授权后执行。视频中的最终流程是推送代码、打包并提 tag，但这不是默认授权。
